"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";

export async function createRequestAction(formData: FormData) {
  const profile = await requireRole(["client"]);
  const supabase = await createClient();
  const budgetMin = Number(formData.get("budget_min"));
  const budgetMax = Number(formData.get("budget_max"));
  const title = String(formData.get("title") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const address = String(formData.get("address") ?? "").trim();
  const desiredTime = String(formData.get("desired_time") ?? "");

  if (!title || !description || !address || !desiredTime || Number.isNaN(budgetMin) || Number.isNaN(budgetMax) || budgetMin <= 0 || budgetMax < budgetMin) {
    redirect("/client/requests/new?error=1");
  }

  const payload = {
    client_id: profile.id,
    category_id: Number(formData.get("category_id")),
    title,
    description,
    address,
    city: profile.city,
    budget_min: budgetMin,
    budget_max: budgetMax,
    desired_time: desiredTime
  };

  const { data, error } = await supabase.from("requests").insert(payload).select("id").single();
  if (error) redirect("/client/requests/new?error=1");

  const requestId = data?.id;
  const rawPhotoUrls = String(formData.get("photo_urls") ?? "");
  const photoUrls = rawPhotoUrls
    .split(/\r?\n|,/)
    .map((item) => item.trim())
    .filter((item) => item.startsWith("http://") || item.startsWith("https://"))
    .slice(0, 5);

  if (requestId && photoUrls.length) {
    await supabase.from("request_photos").insert(photoUrls.map((url) => ({ request_id: requestId, photo_url: url })));
  }

  revalidatePath("/client/requests");
  redirect("/client/requests");
}

export async function acceptOfferAction(formData: FormData) {
  await requireRole(["client"]);
  const supabase = await createClient();
  const offerId = Number(formData.get("offer_id"));
  const requestId = Number(formData.get("request_id"));
  if (!offerId || !requestId) return;

  const { error } = await supabase.rpc("accept_offer", {
    p_offer_id: offerId,
    p_request_id: requestId
  });

  if (error) {
    redirect(`/client/requests/${requestId}?error=offer`);
  }

  revalidatePath(`/client/requests/${requestId}`);
  redirect(`/client/requests/${requestId}?accepted=1`);
}
