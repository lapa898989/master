import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { createClient } from "@/lib/supabase/server";

export const metadata: Metadata = {
  title: "ServiceDrive MVP",
  description: "Маркетплейс бытовых услуг в формате заявок и откликов"
};

async function signOut() {
  "use server";
  const supabase = await createClient();
  await supabase.auth.signOut();
}

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const supabase = await createClient();
  const {
    data: { user }
  } = await supabase.auth.getUser();

  return (
    <html lang="ru">
      <body>
        <header className="border-b bg-white">
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <Link href="/" className="font-semibold text-indigo-600">
              ServiceDrive
            </Link>
            <div className="flex items-center gap-4 text-sm">
              <Link href="/client/requests">Клиент</Link>
              <Link href="/master/requests">Мастер</Link>
              <Link href="/admin">Админ</Link>
              {user ? (
                <form action={signOut}>
                  <button type="submit" className="rounded bg-slate-900 px-3 py-1 text-white">
                    Выйти
                  </button>
                </form>
              ) : (
                <Link href="/auth/login" className="rounded bg-indigo-600 px-3 py-1 text-white">
                  Войти
                </Link>
              )}
            </div>
          </nav>
        </header>
        <main className="mx-auto max-w-6xl px-4 py-6">{children}</main>
      </body>
    </html>
  );
}
