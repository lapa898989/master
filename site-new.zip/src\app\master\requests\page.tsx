import { upsertOfferAction } from "@/app/master/actions";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function MasterRequestsPage(props: { searchParams: Promise<{ category?: string }> }) {
  const searchParams = await props.searchParams;
  const profile = await requireRole(["master"]);
  const supabase = await createClient();
  const selectedCategory = Number(searchParams.category ?? 0);
  const { data: categories } = await supabase.from("categories").select("id,name").order("name");

  let query = supabase
    .from("requests")
    .select("id, title, description, budget_min, budget_max, city, status, category_id, categories:category_id(name)")
    .eq("status", "open")
    .eq("city", profile.city)
    .order("created_at", { ascending: false });

  if (selectedCategory > 0) {
    query = query.eq("category_id", selectedCategory);
  }

  const { data: requests } = await query;

  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-semibold">Доступные заявки</h1>
      <div className="flex flex-wrap gap-2">
        <Link href="/master/requests" className={`rounded px-3 py-1 text-sm ${selectedCategory ? "bg-white border" : "bg-indigo-600 text-white"}`}>
          Все категории
        </Link>
        {categories?.map((c) => (
          <Link
            key={c.id}
            href={`/master/requests?category=${c.id}`}
            className={`rounded px-3 py-1 text-sm ${selectedCategory === c.id ? "bg-indigo-600 text-white" : "bg-white border"}`}
          >
            {c.name}
          </Link>
        ))}
      </div>
      <div className="space-y-3">
        {requests?.map((request) => (
          <article key={request.id} className="rounded bg-white p-4 shadow-sm">
            <p className="font-medium">{request.title}</p>
            <p className="text-xs text-slate-500">Категория: {(request.categories as { name: string } | null)?.name ?? "-"}</p>
            <p className="text-sm text-slate-600">{request.description}</p>
            <p className="text-sm">
              Бюджет: {request.budget_min}-{request.budget_max} RUB
            </p>
            <form action={upsertOfferAction} className="mt-3 grid gap-2 md:grid-cols-3">
              <input type="hidden" name="request_id" value={request.id} />
              <input name="price" type="number" min={100} required placeholder="Ваша цена" className="rounded border p-2" />
              <input name="eta_minutes" type="number" min={10} required placeholder="Сколько минут" className="rounded border p-2" />
              <input name="comment" required placeholder="Комментарий" className="rounded border p-2" />
              <button type="submit" className="rounded bg-indigo-600 px-3 py-2 text-white md:col-span-3">
                Отправить отклик
              </button>
            </form>
          </article>
        ))}
      </div>
    </section>
  );
}
