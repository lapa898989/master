import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const formData = await request.formData();

  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") ?? "");
  const role = String(formData.get("role") ?? "client");
  const fullName = String(formData.get("full_name") ?? "").trim();
  const city = String(formData.get("city") ?? "").trim();
  const normalizedRole = role === "master" ? "master" : "client";

  if (!email || password.length < 6 || !fullName || !city) {
    return NextResponse.redirect(
      new URL("/auth/register?error=Заполните%20все%20поля%20и%20пароль%20не%20короче%206%20символов", request.url)
    );
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        role: normalizedRole,
        full_name: fullName,
        city
      }
    }
  });

  if (error) {
    return NextResponse.redirect(new URL(`/auth/register?error=${encodeURIComponent(error.message)}`, request.url));
  }

  if (!data.user) {
    return NextResponse.redirect(new URL("/auth/register?error=Не%20удалось%20создать%20пользователя", request.url));
  }

  // Supabase can return a user object for an existing email, but with no identities.
  if (Array.isArray(data.user.identities) && data.user.identities.length === 0) {
    return NextResponse.redirect(new URL("/auth/register?error=Пользователь%20с%20таким%20email%20уже%20существует", request.url));
  }

  return NextResponse.redirect(new URL("/auth/login?registered=1", request.url));
}

