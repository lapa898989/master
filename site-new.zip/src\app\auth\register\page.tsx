export default async function RegisterPage(props: { searchParams: Promise<{ error?: string }> }) {
  const searchParams = await props.searchParams;
  return (
    <section className="mx-auto max-w-md space-y-4 rounded bg-white p-6 shadow">
      <h1 className="text-2xl font-semibold">Регистрация</h1>
      {searchParams.error ? <p className="text-sm text-red-700">{decodeURIComponent(searchParams.error)}</p> : null}
      <form action="/auth/register" method="post" className="space-y-3">
        <input name="full_name" placeholder="Имя" required className="w-full rounded border p-2" />
        <input name="city" placeholder="Город" required className="w-full rounded border p-2" />
        <select name="role" className="w-full rounded border p-2">
          <option value="client">Клиент</option>
          <option value="master">Мастер</option>
        </select>
        <input name="email" type="email" placeholder="Email" required className="w-full rounded border p-2" />
        <input name="password" type="password" minLength={6} placeholder="Пароль" required className="w-full rounded border p-2" />
        <button type="submit" className="w-full rounded bg-indigo-600 p-2 text-white">
          Создать аккаунт
        </button>
      </form>
    </section>
  );
}
