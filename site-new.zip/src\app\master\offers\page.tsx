import Link from "next/link";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";

export default async function MasterOffersPage() {
  const profile = await requireRole(["master"]);
  const supabase = await createClient();

  const { data: offers } = await supabase
    .from("offers")
    .select("id, price, status, requests:request_id(id, title, status)")
    .eq("master_id", profile.id)
    .order("created_at", { ascending: false });

  return (
    <section className="space-y-4">
      <h1 className="text-2xl font-semibold">Мои отклики</h1>
      <div className="space-y-2">
        {offers?.map((offer) => {
          const request = offer.requests as { id: number; title: string; status: string } | null;
          return (
            <article key={offer.id} className="rounded bg-white p-4 shadow-sm">
              <p className="font-medium">{request?.title ?? "Заявка удалена"}</p>
              <p className="text-sm text-slate-600">
                Статус отклика: {offer.status}, цена: {offer.price}
              </p>
              {request ? (
                <div className="mt-2 flex gap-3">
                  <Link href={`/client/requests/${request.id}`} className="text-sm text-indigo-600">
                    Открыть заявку
                  </Link>
                  {request.status === "in_progress" ? (
                    <Link href={`/chat/${request.id}`} className="text-sm text-slate-900">
                      Чат по заказу
                    </Link>
                  ) : null}
                </div>
              ) : null}
            </article>
          );
        })}
      </div>
    </section>
  );
}
