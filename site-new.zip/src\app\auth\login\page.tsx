import Link from "next/link";

export default async function LoginPage(props: { searchParams: Promise<{ error?: string; registered?: string }> }) {
  const searchParams = await props.searchParams;
  return (
    <section className="mx-auto max-w-md space-y-4 rounded bg-white p-6 shadow">
      <h1 className="text-2xl font-semibold">Вход</h1>
      {searchParams.registered ? <p className="text-sm text-green-700">Аккаунт создан, можно входить.</p> : null}
      {searchParams.error ? <p className="text-sm text-red-700">{decodeURIComponent(searchParams.error)}</p> : null}
      <form action="/auth/login" method="post" className="space-y-3">
        <input name="email" type="email" placeholder="Email" required className="w-full rounded border p-2" />
        <input name="password" type="password" placeholder="Пароль" required className="w-full rounded border p-2" />
        <button type="submit" className="w-full rounded bg-indigo-600 p-2 text-white">
          Войти
        </button>
      </form>
      <p className="text-sm">
        Нет аккаунта?{" "}
        <Link className="text-indigo-600" href="/auth/register">
          Регистрация
        </Link>
      </p>
    </section>
  );
}
