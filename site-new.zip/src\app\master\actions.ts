"use server";

import { revalidatePath } from "next/cache";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";

export async function upsertOfferAction(formData: FormData) {
  const profile = await requireRole(["master"]);
  const supabase = await createClient();

  const requestId = Number(formData.get("request_id"));
  const price = Number(formData.get("price"));
  const etaMinutes = Number(formData.get("eta_minutes"));
  const comment = String(formData.get("comment") ?? "").trim();
  if (!requestId || Number.isNaN(price) || price <= 0 || Number.isNaN(etaMinutes) || etaMinutes <= 0 || !comment) {
    return;
  }
  const payload = {
    request_id: requestId,
    master_id: profile.id,
    price,
    comment,
    eta_minutes: etaMinutes
  };

  await supabase
    .from("offers")
    .upsert(payload, { onConflict: "request_id,master_id", ignoreDuplicates: false })
    .select("id");

  revalidatePath("/master/requests");
  revalidatePath("/master/offers");
  revalidatePath(`/client/requests/${requestId}`);
}
