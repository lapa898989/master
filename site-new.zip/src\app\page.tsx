import Link from "next/link";

export default function Home() {
  return (
    <section className="space-y-6">
      <h1 className="text-3xl font-bold">Маркетплейс услуг в стиле inDrive</h1>
      <p className="max-w-2xl text-slate-600">
        Клиент размещает заявку, мастера по категории отправляют ценовые предложения, клиент выбирает исполнителя.
      </p>
      <div className="flex gap-3">
        <Link href="/auth/register" className="rounded bg-indigo-600 px-4 py-2 text-white">
          Регистрация
        </Link>
        <Link href="/auth/login" className="rounded border border-slate-300 px-4 py-2">
          Вход
        </Link>
      </div>
    </section>
  );
}
