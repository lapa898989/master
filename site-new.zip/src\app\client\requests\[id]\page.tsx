import { acceptOfferAction } from "@/app/client/actions";
import { RequestOffersLive } from "@/components/request-offers-live";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function ClientRequestDetailsPage({
  params,
  searchParams
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; accepted?: string }>;
}) {
  const p = await params;
  const s = await searchParams;
  const requestId = Number(p.id);
  const profile = await requireRole(["client"]);
  const supabase = await createClient();

  const { data: request } = await supabase
    .from("requests")
    .select("id, title, description, status, client_id")
    .eq("id", requestId)
    .single();

  if (!request || request.client_id !== profile.id) {
    return <p>Заявка не найдена.</p>;
  }

  const { data: offers } = await supabase
    .from("offers")
    .select("id, price, comment, eta_minutes, status, profiles:master_id(full_name)")
    .eq("request_id", requestId)
    .order("created_at", { ascending: true });

  const { data: photos } = await supabase.from("request_photos").select("id, photo_url").eq("request_id", requestId).order("created_at");

  const { data: assignment } = await supabase
    .from("assignments")
    .select("id")
    .eq("request_id", requestId)
    .maybeSingle();

  return (
    <section className="space-y-4">
      <RequestOffersLive requestId={requestId} />
      {s.accepted ? <p className="rounded bg-green-100 px-3 py-2 text-sm text-green-700">Исполнитель успешно выбран.</p> : null}
      {s.error ? <p className="rounded bg-red-100 px-3 py-2 text-sm text-red-700">Не удалось выбрать отклик. Попробуйте еще раз.</p> : null}
      <h1 className="text-2xl font-semibold">{request.title}</h1>
      <p className="rounded bg-white p-4">{request.description}</p>
      {photos?.length ? (
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
          {photos.map((photo) => (
            <a key={photo.id} href={photo.photo_url} target="_blank" rel="noreferrer" className="block overflow-hidden rounded border bg-white">
              <img src={photo.photo_url} alt="Фото заявки" className="h-36 w-full object-cover" />
            </a>
          ))}
        </div>
      ) : null}
      <p className="text-sm text-slate-600">Статус: {request.status}</p>
      {assignment ? (
        <Link href={`/chat/${requestId}`} className="inline-block rounded bg-slate-900 px-3 py-2 text-sm text-white">
          Открыть чат с мастером
        </Link>
      ) : null}
      <h2 className="text-xl font-semibold">Отклики мастеров</h2>
      <div className="space-y-2">
        {offers?.map((offer) => (
          <article key={offer.id} className="rounded bg-white p-4 shadow-sm">
            <p className="font-medium">Мастер: {(offer.profiles as { full_name: string } | null)?.full_name ?? "Без имени"}</p>
            <p>
              Цена: <b>{offer.price} RUB</b> | ETA: {offer.eta_minutes} мин
            </p>
            <p className="text-sm text-slate-600">{offer.comment}</p>
            {offer.status === "pending" && request.status === "open" ? (
              <form action={acceptOfferAction} className="mt-3">
                <input type="hidden" name="offer_id" value={offer.id} />
                <input type="hidden" name="request_id" value={requestId} />
                <button type="submit" className="rounded bg-green-600 px-3 py-1 text-white">
                  Выбрать мастера
                </button>
              </form>
            ) : null}
          </article>
        ))}
      </div>
    </section>
  );
}
