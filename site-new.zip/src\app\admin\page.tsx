import { updateProfileBanAction, updateRequestStatusAction } from "@/app/admin/actions";
import { requireRole } from "@/lib/auth/roles";
import { createClient } from "@/lib/supabase/server";

export default async function AdminPage() {
  await requireRole(["admin"]);
  const supabase = await createClient();
  const { data: users } = await supabase.from("profiles").select("id, full_name, role, is_banned").order("created_at", { ascending: false }).limit(20);
  const { data: requests } = await supabase.from("requests").select("id, title, status").order("created_at", { ascending: false }).limit(20);

  return (
    <section className="space-y-8">
      <h1 className="text-2xl font-semibold">Админ-панель</h1>

      <div className="space-y-3">
        <h2 className="text-xl font-medium">Пользователи</h2>
        {users?.map((user) => (
          <article key={user.id} className="rounded bg-white p-4 shadow-sm">
            <p>
              {user.full_name} ({user.role}) - {user.is_banned ? "Заблокирован" : "Активен"}
            </p>
            <form action={updateProfileBanAction} className="mt-2 flex gap-2">
              <input type="hidden" name="profile_id" value={user.id} />
              <button type="submit" name="is_banned" value={user.is_banned ? "false" : "true"} className="rounded bg-slate-800 px-3 py-1 text-white">
                {user.is_banned ? "Разблокировать" : "Заблокировать"}
              </button>
            </form>
          </article>
        ))}
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-medium">Заявки</h2>
        {requests?.map((request) => (
          <article key={request.id} className="rounded bg-white p-4 shadow-sm">
            <p>
              #{request.id} {request.title}
            </p>
            <p className="text-sm text-slate-600">Текущий статус: {request.status}</p>
            <form action={updateRequestStatusAction} className="mt-2 flex items-center gap-2">
              <input type="hidden" name="request_id" value={request.id} />
              <select name="status" className="rounded border p-1">
                <option value="open">open</option>
                <option value="in_progress">in_progress</option>
                <option value="done">done</option>
                <option value="cancelled">cancelled</option>
              </select>
              <button type="submit" className="rounded bg-indigo-600 px-3 py-1 text-white">
                Обновить
              </button>
            </form>
          </article>
        ))}
      </div>
    </section>
  );
}
