import { NextResponse } from "next/server";

import { createClient } from "@/lib/supabase/server";

export async function POST(request: Request) {
  const formData = await request.formData();
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) {
    return NextResponse.redirect(new URL("/auth/login?error=Введите%20email%20и%20пароль", request.url));
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    return NextResponse.redirect(new URL(`/auth/login?error=${encodeURIComponent(error.message)}`, request.url));
  }

  const {
    data: { user }
  } = await supabase.auth.getUser();
  const { data } = await supabase.from("profiles").select("role,is_banned").eq("id", user?.id ?? "").single();

  if (data?.is_banned) {
    await supabase.auth.signOut();
    return NextResponse.redirect(new URL("/auth/login?error=Ваш%20аккаунт%20заблокирован", request.url));
  }

  const role = data?.role ?? "client";
  if (role === "master") return NextResponse.redirect(new URL("/master/requests", request.url));
  if (role === "admin") return NextResponse.redirect(new URL("/admin", request.url));
  return NextResponse.redirect(new URL("/client/requests", request.url));
}

